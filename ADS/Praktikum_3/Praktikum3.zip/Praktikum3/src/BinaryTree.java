
import java.io.BufferedReader;

import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;



/**
 * ADS FS2019 
 * Praktikum 3
 * 
 * 
 * @author Gabriele Pace (pacegab1), Omar Shakir (shakioma)
 */

public class BinaryTree<E extends Comparable<E>> {
	private TreeNode<E> rootNode;
	
	ArrayList<E> preOrderedList = new ArrayList<E>();
	ArrayList<E> inOrderedList = new ArrayList<E>();
	ArrayList<E> postOrderedList = new ArrayList<E>();
	ArrayList<E> levelOrderedList = new ArrayList<E>();

	public BinaryTree() {
		rootNode = null;
	}

	public BinaryTree(E element) {
		rootNode = new TreeNode<E>(element);
	}

	

	public ArrayList<E> traversePreorder() {
		TreeNode<E> currentNode = rootNode;
		preOrder(currentNode);
		return preOrderedList;
	}

	public void preOrder(TreeNode<E> currentNode) {
		if (currentNode == null)
			return;

		preOrderedList.add(currentNode.getElement());
		preOrder(currentNode.getLeft());
		preOrder(currentNode.getRight());
	}

	

	public ArrayList<E> traverseInorder() {
		TreeNode<E> currentNode = rootNode;
		inOrder(currentNode);
		return inOrderedList;
	}

	public void inOrder(TreeNode<E> currentNode) {
		if (currentNode == null)
			return;

		inOrder(currentNode.getLeft());
		inOrderedList.add(currentNode.getElement());
		inOrder(currentNode.getRight());
	}

	

	public ArrayList<E> traversePostorder() {
		TreeNode<E> currentNode = rootNode;
		postOrder(currentNode);
		return postOrderedList;
	}

	public void postOrder(TreeNode<E> currentNode) {
		if (currentNode == null)
			return;

		postOrder(currentNode.getLeft());
		postOrder(currentNode.getRight());
		postOrderedList.add(currentNode.getElement());
	}

	

	public ArrayList<E> traverseLevelorder() {
		TreeNode<E> currentNode = rootNode;
		int height = treeHeight(currentNode);
		for (int level = 1; level <= height; level++)
			levelOrder(currentNode, level);
		return levelOrderedList;
	}

	public void levelOrder(TreeNode<E> currentNode, int level) {
		if (currentNode == null)
			return;
		if (level == 1)
			levelOrderedList.add(currentNode.getElement());
		else
			levelOrder(currentNode.getLeft(), level - 1);
		levelOrder(currentNode.getRight(), level - 1);
	}

	

	public int treeHeight(TreeNode<E> currentNode) {
		if (currentNode == null)
			return 0;

		int leftHeight = treeHeight(currentNode.getLeft());
		int rightHeight = treeHeight(currentNode.getRight());

		if (leftHeight > rightHeight)
			return (leftHeight + 1);
		else
			return (rightHeight + 1);
	}

	public void add(E element) {
		if (rootNode == null) {
			setRoot(new TreeNode<E>(element));
			return;
		}
		rootNode.add(element);
	}
	
	public TreeNode<E> find(E element, TreeNode<E> currentNode) {
		if(currentNode == null)
			return null;
		
		int comparison = currentNode.getElement().compareTo(element);
		if(comparison == 0){
           return currentNode;
        } else {
            TreeNode<E> foundNode = find(element, currentNode.getLeft());
            if(foundNode == null)
                foundNode = find(element, currentNode.getRight());
            return foundNode;
         }
	}

	public TreeNode<E> getRoot() {
		return rootNode;
	}

	public void setRoot(TreeNode<E> rootNode) {
		this.rootNode = rootNode;
	}

	public static void main(String args[]) throws NumberFormatException, NullPointerException, ParseException {
		// Parse csv file and add all competitors to the array list
		ArrayList<Competitor> competitors = new ArrayList<Competitor>();
		String line = "";
		String cvsSplitBy = ",";
		try (BufferedReader br = new BufferedReader(new FileReader("/Users/omar/workspace/Praktikum_3/src/Teilnehmerliste.csv"))) {
			while ((line = br.readLine()) != null) {
				String[] competitor = line.split(cvsSplitBy);
				competitors.add((new Competitor(Integer.parseInt(competitor[0]), competitor[1], competitor[2], Integer.parseInt(competitor[3]), competitor[4], competitor[5])));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		BinaryTree<Competitor> binaryTree = new BinaryTree<Competitor>();
		for(Competitor competitor : competitors) {
			binaryTree.add(competitor);
		}
		
		
		Competitor competitorToFind = competitors.get(5);
		TreeNode<Competitor> foundNode = binaryTree.find(competitorToFind, binaryTree.getRoot());
		System.out.println(foundNode.getElement().toString());
	}
}

