import { StatusBar } from 'expo-status-bar';
import React, { useState } from 'react'
import { StyleSheet, Text, View, FlatList } from 'react-native';
import Header from './components/Header'
import ListItem from './components/ListItem'
import data from './results'
import axios from 'axios'

export default function App() {

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
      alignItems: 'center',
      justifyContent: 'center',
    },
  });

  const [items, setItems] = useState([
    {
      id: "1",
      text: 'Milk',
    },
    {
      id: "2",
      text: 'Eggs',
    },
    {
      id: "3",
      text: 'Bread',
    },
  ])

  const [json, setJson] = useState(data.items);

  //axios.get('https://api.github.com/search/repositories?q=lol').then(response => setJson(response.data.items))

  console.log(json);

  return (
    <View>
      <Header title="Results" />
      <FlatList data={json}
        renderItem={({ item }) => (
          <ListItem item={item} />
        )}
      />
    </View>
  )
}


