package aufagabe1;

import java.util.Collections;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * ADS FS2019 
 * Praktikum 4
 * 
 * 
 * @author Gabriele Pace (pacegab1), Omar Shakir (shakioma)
 */

public class HanoiServer implements CommandExecutor {
    @Override
    public String execute(final String command) throws Exception {
        String instructionsString;

        try {
            final int size = Integer.parseInt(command);

            if (size < 0) {
                throw new IllegalArgumentException("Die Turmgröße muss nicht negativ sein.");
            }

            List<Instruction> instructions = hanoi(size, 'A', 'B', 'C');

            instructionsString = instructions.stream()
                    .map(i -> "move " + i.getFrom() + " to " + i.getTo())
                    .collect(Collectors.joining("\n", "", ""));
        } catch (IllegalArgumentException e) {
            instructionsString = "Die Turmgröße muss eine nicht negative integer.";
        }

        return "Instructions:\n" + instructionsString + "\n";
    }

    private static List<Instruction> hanoi(final int size, final char source, final char target, final char intermediate) {
        if (size == 0) {
            return Collections.emptyList();
        }
        if (size == 1) {
            return Collections.singletonList(new Instruction(source, target));
        }
        List<Instruction> list = new LinkedList<>();

        list.addAll(hanoi(size - 1, source, intermediate, target));
        list.addAll(hanoi(1, source, target, intermediate));
        list.addAll(hanoi(size - 1, intermediate, target, source));

        return list;
    }

    private static class Instruction {
        private final char from;
        private final char to;

        private Instruction(final char from, final char to) {
            this.from = from;
            this.to = to;
        }

        private char getFrom() {
            return from;
        }

        private char getTo() {
            return to;
        }
    }
}

