import React from 'react'
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native'



const ListItem = ({item, deleteItem}) => {
  //console.log(item)
  return (
    <TouchableOpacity style={styles.listItem}>
      <View style={styles.listItemView}>
        <Text style={styles.listItemTitle}>{item.name}</Text>
        <Text style={styles.listItemText}>{item.description}</Text>
      </View>
    </TouchableOpacity>
  )
}

const styles = StyleSheet.create({
  listItem: {
    padding: 15,
    backgroundColor: '#f8f8f8',
    borderBottomWidth: 1,
    borderColor: '#eee',
  },
  listItemView: {
    // flexDirection: 'row',
    // justifyContent: 'space-between',
    // alignItems: 'center',
  },
  listItemTitle: {
    fontSize: 25,
    display: "block",
  },
  listItemText: {
    fontSize: 18,
    display: "block",
  },
})

export default ListItem
