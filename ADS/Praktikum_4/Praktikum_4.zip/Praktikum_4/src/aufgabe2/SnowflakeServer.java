package aufgabe2;

import aufagabe1.CommandExecutor;

/**
 * ADS FS2019 
 * Praktikum 4
 * 
 * 
 * @author Gabriele Pace (pacegab1), Omar Shakir (shakioma)
 */

public class SnowflakeServer implements CommandExecutor {
    private Turtle turtle;

    @Override
    public String execute(final String command) {
        final double triangleSideLength = 0.5;
        final double triangleHeight = Math.sqrt(3) * triangleSideLength / 2;

        final double snowFlakeWidth = triangleSideLength;
        final double snowFlakeHeight = 4 * triangleHeight / 3;

        final double xCorner = (1 - snowFlakeWidth) / 2;
        final double yCorner = (1 + snowFlakeHeight) / 2;

        turtle = new Turtle(xCorner, yCorner - triangleHeight / 3);

        final int degree = Integer.parseInt(command);

        for (int triangleSideIndex = 0; triangleSideIndex < 3; ++triangleSideIndex) {
            snowflake(degree, triangleSideLength);
            turtle.turn(-120);
        }

        return turtle.getTrace();
    }

    private void snowflake(final int degree, final double distance) {
        if (degree == 0) {
            turtle.move(distance);
            return;
        }
        final Runnable subSnowflake = () -> snowflake(degree - 1, distance / 3);

        subSnowflake.run();
        turtle.turn(60);
        subSnowflake.run();
        turtle.turn(-120);
        subSnowflake.run();
        turtle.turn(60);
        subSnowflake.run();
    }
}
