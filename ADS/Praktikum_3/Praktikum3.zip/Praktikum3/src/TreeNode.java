

/**
 * ADS FS2019 
 * Praktikum 3
 * 
 * 
 * @author Gabriele Pace (pacegab1), Omar Shakir (shakioma)
 */
public final class TreeNode<E extends Comparable<E>> {

    private E element;
    private TreeNode<E> left;
    private TreeNode<E> right;

    public TreeNode(E element) {
        this.element = element;
    }

    
    @Override
    public String toString() {
        return (getClass().getName() + "["
                + "element=" + element
                + "]");
    }

   
    public E getElement() {
        return element;
    }

    
    public void setElement(E element) {
        this.element = element;
    }

   
    public TreeNode<E> getLeft() {
        return left;
    }

    
    public void setLeft(TreeNode<E> left) {
        this.left = left;
    }

   
    public TreeNode<E> getRight() {
        return right;
    }

   
    public void setRight(TreeNode<E> right) {
        this.right = right;
    }

	public void add(E element) {
		int comparison = this.element.compareTo(element);
		if(comparison == 0) {
			return;
		} else if(comparison > 0) {
			// argument element is lexicographically greater
			if (getRight() == null) {
				setRight(new TreeNode<E>(element));
			} else getRight().add(element);
		} else if(comparison < 0) {
			// argument element is lexicographically lesser
			if (getLeft() == null) {
				setLeft(new TreeNode<E>(element));
			} else getLeft().add(element);
		}
	}
}
