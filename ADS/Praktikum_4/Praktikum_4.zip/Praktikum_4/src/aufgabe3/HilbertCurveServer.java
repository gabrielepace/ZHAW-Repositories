package aufgabe3;

import java.util.function.Consumer;

import aufagabe1.CommandExecutor;
import aufgabe2.Turtle;
/**
 * ADS FS2019 
 * Praktikum 4
 * 
 * 
 * @author Gabriele Pace (pacegab1), Omar Shakir (shakioma)
 */

public class HilbertCurveServer implements CommandExecutor {
    private Turtle turtle;

    @Override
    public String execute(String command) {
        final int degree = Integer.parseInt(command);
        final long numberOfRows = 2 << degree;
        final double segmentLength = 1.0 / numberOfRows;

        turtle = new Turtle(segmentLength / 2, segmentLength / 2);
        hilbertCurve(degree, 1, 90, segmentLength);

        return turtle.getTrace();
    }

    private void hilbertCurve(final int degree, final double distance, final int angle, final double segmentLength) {
        if (degree < 0) {
            return;
        }
        final double subDistance = distance / 2;
        final Consumer<Integer> subHilbertCurve = a -> hilbertCurve(degree - 1, subDistance, -a, segmentLength);

        turtle.turn(angle);
        subHilbertCurve.accept(angle);
        turtle.move(segmentLength);
        turtle.turn(-angle);
        subHilbertCurve.accept(-angle);
        turtle.move(segmentLength);
        subHilbertCurve.accept(-angle);
        turtle.turn(-angle);
        turtle.move(segmentLength);
        subHilbertCurve.accept(angle);
        turtle.turn(angle);
    }
}

