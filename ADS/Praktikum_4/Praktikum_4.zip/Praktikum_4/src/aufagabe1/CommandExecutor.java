
package aufagabe1;

public interface CommandExecutor {

    
   
    String execute(String command) throws Exception;
}//interface CommandExecutor
